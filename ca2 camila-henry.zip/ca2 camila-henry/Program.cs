﻿using System;

class Node
{
    public int valor;
    public Node next;
    public Node(int Valor)
    {
        this.valor = Valor;
        this.next = null;
    }
}

public class ListaCircular
{
    private Node cola;
    private int tamano;

    public ListaCircular()
    {
        cola = null;
        tamano = 0;
    }

    public void insertar_al_inicio(int valor)
    {
        Node nodonuevo = new Node(valor);
        if (this.cola == null)
        {
            this.cola = nodonuevo;
            this.cola.next = this.cola;
        }
        else
        {
            nodonuevo.next = this.cola.next;
            this.cola.next = nodonuevo;
        }
        this.tamano++;
    }

    public void insertar_al_final(int valor)
    {
        Node nodonuevo = new Node(valor);
        if (this.cola == null)
        {
            this.cola = nodonuevo;
            this.cola.next = this.cola;
        }
        else
        {
            nodonuevo.next = this.cola.next;
            this.cola.next = nodonuevo;
            this.cola = nodonuevo;
        }
        this.tamano++;
    }

    public void insertar_en_posicion(int valor, int posicion)
    {
        if (posicion < 0 || posicion > this.tamano)
        {
            throw new ArgumentException("Posicion invalida");
        }
        else
        {
            if (posicion == 0)
            {
                this.insertar_al_inicio(valor);
            }
            else if (posicion == this.tamano)
            {
                this.insertar_al_final(valor);
            }
            else
            {
                Node nodonuevo = new Node(valor);
                Node aux = this.cola.next;
                for (int i = 0; i < posicion - 1; i++)
                {
                    aux = aux.next;
                }
                nodonuevo.next = aux.next;
                aux.next = nodonuevo;
                this.tamano++;
            }
        }
    }

    public void eliminar_al_inicio()
    {
        if (this.cola == null)
        {
            Console.WriteLine("No hay elementos en la lista");
            return;
        }
        else
        {
            if (this.cola.next == this.cola)
            {
                this.cola = null;
            }
            else
            {
                this.cola.next = this.cola.next.next;
            }
            this.tamano--;
        }
    }

    public void eliminar_al_final()
    {
        if (this.cola == null)
        {
            Console.WriteLine("No hay elementos en la lista");
            return;
        }
        else
        {
            if (this.cola.next == this.cola)
            {
                this.cola = null;
            }
            else
            {
                Node aux = this.cola.next;
                while (aux.next != this.cola)
                {
                    aux = aux.next;
                }
                aux.next = this.cola.next;
                this.cola = aux;
            }
            this.tamano--;
        }
    }

    public void eliminar_en_posicion(int posicion)
    {
        if (posicion < 0 || posicion >= this.tamano)
        {
            throw new ArgumentException("Posicion invalida");
        }
        else
        {
            if (posicion == 0)
            {
                this.eliminar_al_inicio();
            }
            else if (posicion == this.tamano - 1)
            {
                this.eliminar_al_final();
            }
            else
            {
                Node aux = this.cola.next;
                for (int i = 0; i < posicion - 1; i++)
                {
                    aux = aux.next;
                }
                aux.next = aux.next.next;
                this.tamano--;
            }
        }
    }

    public string ToString()
    {
        string cadena = "";
        if (this.cola != null)
        {
            Node aux = this.cola.next;
            do
            {
                cadena += aux.valor + ",";
                aux = aux.next;
            } while (aux != this.cola.next);
            cadena = cadena.TrimEnd(',');
        }
        return cadena;
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        ListaCircular lista = new ListaCircular();

        lista.insertar_al_inicio(1);
        lista.insertar_al_inicio(2);
        lista.insertar_al_final(3);
        lista.insertar_en_posicion(4, 2); // Inserta en la posición 2

        Console.WriteLine("Lista después de inserciones: " + lista.ToString());

        lista.eliminar_al_inicio();
        Console.WriteLine("Lista después de eliminar al inicio: " + lista.ToString());

        lista.eliminar_al_final();
        Console.WriteLine("Lista después de eliminar al final: " + lista.ToString());

        lista.eliminar_en_posicion(1); // Elimina el elemento en la posición 1
        Console.WriteLine("Lista después de eliminar en posición 1: " + lista.ToString());
    }
}
