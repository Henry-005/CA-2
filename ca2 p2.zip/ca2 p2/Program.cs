﻿using System;

class Node
{
    public int valor;
    public Node next;
    public Node prev;
    public Node(int Valor)
    {
        this.valor = Valor;
        this.next = null;
        this.prev = null;
    }
}

public class ListaDobleCircular  // Cambié el modificador de acceso a 'public'
{
    private Node cola;
    private int tamano;

    public ListaDobleCircular()
    {
        cola = null;
        tamano = 0;
    }

    public void insertar_al_inicio(int valor)
    {
        Node nodonuevo = new Node(valor);
        if (this.cola == null)
        {
            this.cola = nodonuevo;
            this.cola.next = this.cola;
            this.cola.prev = this.cola;
        }
        else
        {
            nodonuevo.next = this.cola.next;
            nodonuevo.prev = this.cola;
            this.cola.next.prev = nodonuevo;
            this.cola.next = nodonuevo;
        }
        this.tamano++;
    }

    public void insertar_al_final(int valor)
    {
        Node nodonuevo = new Node(valor);
        if (this.cola == null)
        {
            this.cola = nodonuevo;
            this.cola.next = this.cola;
            this.cola.prev = this.cola;
        }
        else
        {
            nodonuevo.next = this.cola.next;
            nodonuevo.prev = this.cola;
            this.cola.next.prev = nodonuevo;
            this.cola.next = nodonuevo;
            this.cola = nodonuevo;
        }
        this.tamano++;
    }

    public void insertar_en_posicion(int valor, int posicion)
    {
        if (posicion < 0 || posicion > this.tamano)
        {
            System.Console.WriteLine("Posicion invalida");
            return;
        }
        if (posicion == 0)
        {
            this.insertar_al_inicio(valor);
        }
        else if (posicion == this.tamano)
        {
            this.insertar_al_final(valor);
        }
        else
        {
            Node nodonuevo = new Node(valor);
            Node aux = this.cola.next;
            for (int i = 0; i < posicion - 1; i++)
            {
                aux = aux.next;
            }
            nodonuevo.next = aux.next;
            nodonuevo.prev = aux;
            aux.next.prev = nodonuevo;
            aux.next = nodonuevo;
            this.tamano++;
        }
    }

    public void eliminar_al_inicio()
    {
        if (this.cola == null)
        {
            System.Console.WriteLine("No hay elementos en la lista");
            return;
        }
        if (this.cola.next == this.cola)
        {
            this.cola = null;
        }
        else
        {
            this.cola.next = this.cola.next.next;
            this.cola.next.prev = this.cola;
        }
        this.tamano--;
    }

    public void eliminar_al_final()
    {
        if (this.cola == null)
        {
            System.Console.WriteLine("No hay elementos en la lista");
            return;
        }
        if (this.cola.next == this.cola)
        {
            this.cola = null;
        }
        else
        {
            this.cola.prev.next = this.cola.next;
            this.cola.next.prev = this.cola.prev;
            this.cola = this.cola.prev;
        }
        this.tamano--;
    }

    public void eliminar_en_posicion(int posicion)
    {
        if (posicion < 0 || posicion >= this.tamano)
        {
            System.Console.WriteLine("Posicion invalida");
            return;
        }
        if (posicion == 0)
        {
            this.eliminar_al_inicio();
        }
        else if (posicion == this.tamano - 1)
        {
            this.eliminar_al_final();
        }
        else
        {
            Node aux = this.cola.next;
            for (int i = 0; i < posicion - 1; i++)
            {
                aux = aux.next;
            }
            aux.next = aux.next.next;
            aux.next.prev = aux;
            this.tamano--;
        }
    }

    public override string ToString()
    {
        string cadena = "";
        Node aux = this.cola.next;
        do
        {
            cadena += aux.valor + ",";
            aux = aux.next;
        } while (aux != this.cola.next);
        return cadena.TrimEnd(',');
    }
}

class Program
{
    static void Main()
    {
        ListaDobleCircular lista = new ListaDobleCircular();
        lista.insertar_al_final(1);
        lista.insertar_al_final(2);
        System.Console.WriteLine(lista.ToString());
        lista.insertar_al_inicio(3);
        System.Console.WriteLine(lista.ToString());
        lista.insertar_en_posicion(4, 1);
        System.Console.WriteLine(lista.ToString());
        lista.eliminar_al_inicio();
        System.Console.WriteLine(lista.ToString());
        lista.eliminar_al_final();
        System.Console.WriteLine(lista.ToString());
        lista.insertar_al_final(7);
        lista.insertar_al_inicio(2);
        System.Console.WriteLine(lista.ToString());
        lista.insertar_en_posicion(8, 2);
        System.Console.WriteLine(lista.ToString());
        lista.insertar_al_final(3);
        System.Console.WriteLine(lista.ToString());
        lista.eliminar_en_posicion(2);
        System.Console.WriteLine(lista.ToString());
    }
}
